#include "raster2d.h"

void Raster2d::draw(){

    // Ignores all input, draws a white line in the middle of the screen.
    int j = pixel_y(0.5f * (m_y_max - m_y_min) + m_y_min);
    for ( int i = pixel_x(m_x_min); i < pixel_x(m_x_max); ++i)
        m_image->setPixel(i,j,RGBColor(1., 1., 1.));

}

// rasterize line
void Raster2d::draw_line(Line2f l){

    // TODO

}


// rasterize triangle
void Raster2d::draw_triangle(Triangle2f tri){

    // TODO

}



